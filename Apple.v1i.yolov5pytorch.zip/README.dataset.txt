# Apple > 2024-01-03 4:53pm
https://universe.roboflow.com/my-project-o4ex4/apple-zjbkg

Provided by a Roboflow user
License: MIT

